package com.example.assignmentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
EditText MorgageAmount,InterestRate, MorgagePeriod;
Button CalculateEMI;

TextView EMIresult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        MorgageAmount= findViewById(R.id.MorgageAmount);
        InterestRate=findViewById(R.id.InterestRate);
        MorgagePeriod=findViewById(R.id.MorgagePeriod);
        CalculateEMI=findViewById(R.id.CalculateEMI);
        EMIresult=findViewById(R.id.EMIresult);
        //Launch a new activity to show how to use the app on click of tvMoreInfo
        CalculateEMI.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View view){
                calculateEMI();
            }

        });
    }
    private void calculateEMI(){
        double p=Double.parseDouble(MorgageAmount.getText().toString());
        double i=Double.parseDouble(InterestRate.getText().toString());
        int n=Integer.parseInt(MorgagePeriod.getText().toString());
        double r= i/(12*100);///conversion of annual interest to monthly interest
        double emi= (p*r*Math.pow(1+r,n))/(Math.pow(1+r,n)-1);
        System.out.println(emi);
        EMIresult.setText(String.format("EMI value : %.2f", emi));
    }

}